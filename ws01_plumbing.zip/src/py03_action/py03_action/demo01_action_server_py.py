"""
    需求：编写动作服务端，需要解析客户端提交的数据，遍历该数字并累加求和，最终结果需要响应回
         客户端，且请求响应过程中需要生成连续反馈。
    分析：
        1.创建动作服务端对象；
        2.处理提交的目标值；
        3.生成连续反馈；
        4.响应最终结果；
        5.处理取消请求。

    步骤：
        1.导包；
        2.初始化 ROS2 客户端；
        3.定义节点类；
            3-1.创建动作服务端对象；
            3-2.处理提交的目标值（回调函数）--- 默认实现；
            3-3.处理取消请求（回调函数）--- 默认实现；
            3-4.生成连续反馈与最终响应（回调函数）。
        4.调用spin函数，并传入自定义类对象；
        5.释放资源。

"""
# 1.导包
import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from rclpy.action import GoalResponse
from rclpy.action import CancelResponse
from base_interfaces_demo.action import Progress
import time

# 3.自定义节点类
class ProgressActionServer(Node):
    def __init__(self):
        super().__init__("progress_action_server_node_py")
        self.get_logger().info("动作通信客户端创建！")
        # 3-1.创建动作服务端对象；
        # node,action_type, action_name, excute_callback,
        self.server = ActionServer(
            self,
            Progress,
            "get_sum",
            self.execute_callback,
            goal_callback = self.goal_callback,
            cancel_callback = self.cancel_callback
        ) 
        
        # 3-2. 处理动作客户端所提交的目标值 (通过专门的回调函数实现);
    def goal_callback(self, goal_request):
        if goal_request.num <= 1:
            self.get_logger().info("提交的目标值必须大于一！")
            return GoalResponse.REJECT
                
        self.get_logger().info("提交的目标值合法。")
        return GoalResponse.ACCEPT
    
    # 3-3. 处理取消请求 (通过专门的回调函数实现);
    def cancel_callback(self, cancel_request):
        self.get_logger().info("任务取消请求已接收。")
        return CancelResponse.ACCEPT
    
    # 3-4.生成连续反馈与最终响应（回调函数）。
    def execute_callback(self,goal_handle):
        # 1.生成连续反馈
        # 首先要获取目标值，然后遍历，遍历中进行累加，且每循环一次就计算进度，并作为连续反馈发布
        num = goal_handle.request.num
        sum = 0
        
        for i in range(1,num + 1):
            
            #  判断是否接收到了取消请求
            if goal_handle.is_cancel_requested:
                goal_handle.canceled()
                self.get_logger().info("任务取消！")
                return Progress.Result()
            
            sum += i
            feedback = Progress.Feedback()
            feedback.progress = i / num
            goal_handle.publish_feedback(feedback)
            self.get_logger().info("连续反馈：%.2f" % feedback.progress)
            time.sleep(1.0)

        # 2.响应最终结果
        goal_handle.succeed()
        result = Progress.Result()
        result.sum = sum
        
        self.get_logger().info("计算结果：%d" % result.sum)
        return result
    


def main():
    # 2.初始化ROS2客户端
    rclpy.init()
    # 4.调用spin函数，传入自定义类对象；
    rclpy.spin(ProgressActionServer())
    # 5.释放资源
    rclpy.shutdown()

if __name__ == '__main__':
    main()