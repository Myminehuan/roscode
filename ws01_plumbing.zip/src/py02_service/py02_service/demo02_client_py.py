"""
    需求：编写客户端实现，提交两个整型数据，并处理响应的结果
    步骤：
        前提：main函数中需要判断提交的参数是否正确
        1.导包；
        2.初始化 ROS2 客户端；
        3.定义节点类；
            3-1.创建客户端；
            3-2.连接服务器（对于服务通信而言，如果客户端连接不上服务器，那么不能发送请求）；
            3-3.发送请求。
        4.创建对象指针；
          需要调用连接服务的函数，根据连接结果做下一步处理；
          连接服务后，调用请求发送函数；
          再处理响应结果。
        5.释放资源。

"""
# 1.导包
import rclpy
from rclpy.node import Node
from rclpy.logging import get_logger
import sys
from base_interfaces_demo.srv import AddInts
# 3.自定义节点类
class AddIntsServer(Node):
    def __init__(self):
        super().__init__("AddIntsServer_node_py")
        self.get_logger().info("客户端创建了！(python)")
        # 3-1.创建客户端；
        self.client = self.create_client(AddInts,"add_ints")
        # 3-2.连接服务器；
        while not self.client.wait_for_service(1.0):
            self.get_logger().info("服务连接中！")
        
    def send_request(self):
        # 3-3.发送请求。
        request = AddInts.Request()
        request.num1 = int(sys.argv[1]) 
        request.num2 = int(sys.argv[2])
        self.future = self.client.call_async(request)

def main():
    if len(sys.argv) != 3:
        get_logger("rclpy").error("请提交两个整型数据！")
        return
    # 2.初始化ROS2客户端
    rclpy.init()
    client = AddIntsServer()
    # 发送请求
    client.send_request()
    #处理响应
    rclpy.spin_until_future_complete(client,client.future)
    try:
        response = client.future.result()
        client.get_logger().info("响应结果：sum = %d" % response.sum)
    except Exception:
        client.get_logger().error("服务响应失败！")

    # 5.释放资源
    rclpy.shutdown()

if __name__ == '__main__':
    main()