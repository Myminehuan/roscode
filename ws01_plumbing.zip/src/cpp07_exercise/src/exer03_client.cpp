/*
    需求：客户端需要提交目标点坐标，并解析响应结果。
    流程：
        0.解析动态传入的数据，作为目标点坐标；
        1.包含头文件；
        2.初始化 ROS2 客户端；
        3.自定义节点类；
            3-1.构造函数创建客户端；
            3-2.客户端需要连接服务端；
            3-3.发送请求数据。
        4.调用节点对象指针的相关函数；
        5.释放资源。
*/
// 1.包含头文件；
#include "rclcpp/rclcpp.hpp"
#include "base_interfaces_demo/srv/distance.hpp"

using base_interfaces_demo::srv::Distance;
using namespace std::chrono_literals;
// 3.自定义节点类；
class Exer03Client: public rclcpp::Node{
public:
    Exer03Client():Node("exer03_client_node_cpp"){
    RCLCPP_INFO(this->get_logger(),"案例2客户端创建了！");
    // 3-1.创建客户端；
        /*
            模板：服务接口；
            参数：服务话题名称；
            返回值：服务对象指针。
        */
    client_ = this->create_client<Distance>("distance");

    }

    // 3-2.连接服务器（对于服务通信而言，如果客户端连接不上服务器，那么不能发送请求）；
    bool connect_server(){
        // 在指定超时时间内连接服务器，如果连接上了，那么返回 true，否则返回 false；
        // client_->wait_for_service(1s);
        while (!client_->wait_for_service(1s)) //循环以1s为循环时间连接服务器，直到连接到服务器才退出循环。
        {
            // 对 ctrl+c 这个操作作出特殊处理
            // 1.怎么判断 ctrl+c 按下？ 2.如何处理？
            // 按下 ctrl+c 是结束 ROS2 程序，意味着要释放资源，比如：关闭 context。
            if (!rclcpp::ok())
            {
                RCLCPP_INFO(rclcpp::get_logger("rclcpp"),"节点被强行终止！");
                return false;
            }
            RCLCPP_INFO(rclcpp::get_logger("rclcpp"),"服务连接中！");
        }
        
        return true;
    }
    
    // 3-3.发送请求。
    //编写发送请求函数。 ---- 参数是两个整型数据，返回值是提交请求后服务端的返回结果
    rclcpp::Client<Distance>::FutureAndRequestId send_goal(float x,float y,float theta){
        //组织请求数据

        //发送
        /*
            rclcpp::Client<base_interfaces_demo::srv::Exer03Client>::FutureAndRequestId
            anync_send_request(std:shared_ptr<base_interfaces_demo::srv::Exer03Client_Request> request) //Exer03Client::Request
        */
        auto request = std::make_shared<Distance::Request>();
        request->x = x;
        request->y = y;
        request->theta = theta;
        return client_->async_send_request(request);
    } 
    
private:

    rclcpp::Client<Distance>::SharedPtr client_;

};
int main(int argc, char const *argv[])
{
    //0.解析动态传入的数据，作为目标点坐标；
    if (argc != 5)
    {
        RCLCPP_INFO(rclcpp::get_logger("rclcpp"),"请提交x坐标，y坐标与theta三个参数");
        return 1;
    }
    //解析提交的参数
    float goal_x = atof(argv[1]);
    float goal_y = atof(argv[2]);
    float goal_theta = atof(argv[3]);
    RCLCPP_INFO(rclcpp::get_logger("rclcpp"),"%.2f,%.2f,%.2f",goal_x,goal_y,goal_theta);



    // 2.初始化 ROS2 客户端；
    rclcpp::init(argc,argv);

    // 创建客户端对象
    auto client = std::make_shared<Exer03Client>();
    // 调用客户端对象的连接服务器功能
    bool flag = client->connect_server();
    // 根据连接结果做进一步处理
    if (!flag)
    {
        //用节点client_ 打印日志的话，如果连接服务器等待时按下 ctrl+c，会将初始化的context容器释放，节点不能调用
        /* 
            rclcpp::get_logger("name") 不依赖context
        
        */
        //RCLCPP_INFO(client_->get_logger("rclcpp"),"服务器连接失败，程序退出！");

        RCLCPP_INFO(rclcpp::get_logger("rclcpp"),"服务器连接失败，程序退出！");
        return 1;

    }
    //执行后续操作.....
    //调用请求提交函数，接收并处理响应结果
    auto future = client->send_goal(goal_x,goal_y,goal_theta);
    //处理响应
    if (rclcpp::spin_until_future_complete(client,future) == rclcpp::FutureReturnCode::SUCCESS)//成功
    {
        RCLCPP_INFO(client->get_logger(),"两只王八的距离 %.2f米",future.get()->distance);
        
    }
    else//失败
    {
        RCLCPP_INFO(client->get_logger(),"服务响应失败！");
    }


    // 5.释放资源。
    rclcpp::shutdown();

    return 0;
}