"""
    需求：

    步骤：
        1.导包；
        2.初始化 ROS2 客户端；
        3.自定义节点类；
        4.调用spin函数，并传入自定义类对象；
        5.释放资源。

"""
# 1.导包
import rclpy
from rclpy.node import Node

# 3.自定义节点类
class Exer03TFListenerPy(Node):
    def __init__(self):
        super().__init__("exer03_tf_listener_py_node_py")


def main():
    # 2.初始化ROS2客户端
    rclpy.init()
    # 4.调用spin函数，传入自定义类对象；
    rclpy.spin(Exer03TFListenerPy())
    # 5.释放资源
    rclpy.shutdown()

if __name__ == '__main__':
    main()